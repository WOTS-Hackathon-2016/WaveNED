﻿



// Hi there!
//
// This is a simple demo to show you how to interface the sensornetwork sniffer.
// I have kept things extremely simple and hackable.
// You will not find any exception handling and you may find some ugly constructions that will however be very easy to read.
// I have set the target framework to .Net 2.0 so this code will work on pretty much any MONO version, including old buggy versions.
// So Yes, this will run on Linux, Raspberry Pi, Mac etc.. (oh, and Windows)
//
// Happy hacking!
//
// Joost van Velzen / SallandElectronics


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

// added
using System.IO.Ports; 

namespace WaveNedDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SerialPort  com = null;
        DateTime    lastReport;
        Wsn         wsn;

        List<Button> ports = new List<Button>();

        private void button1_Click(object sender, EventArgs e)
        {
            // close com
            if ( com != null )
            {
                if (com.IsOpen)
                {
                    bwReadCom.CancelAsync();
                }

                com.Dispose();
                com = null;
            }

            // remove any buttons we created

            foreach (Button btn in ports)
            {
                Controls.Remove(btn);
            }

            ports = new List<Button>();

            int lastX = button1.Right;

            String[] portNames = SerialPort.GetPortNames();

            // add a button for each port, a bit cumbersome but we avoid using some of the controls that don't work on older verisons of mono

            if (portNames.Length > 1)
            {
                foreach (string portName in portNames)
                {
                    Button btn = new Button();
                    btn.Text = portName;
                    btn.Top = button1.Top;
                    btn.Left = lastX + 5;
                    btn.Width = button1.Width;
                    lastX = btn.Right;
                    btn.Click += portButton_Click;
                    btn.Font = button1.Font;

                    ports.Add(btn);
                    Controls.Add(btn);
                }

                label1.Text = "click on a button to select a com port";
            }
            else
            if ( portNames.Length == 1 )
            {
                com = new SerialPort(portNames[0], 921600, Parity.None, 8, StopBits.One);

                // set end of line to be \r only
                com.NewLine = "\r";

                com.Open();

                // this way we wait at least one tenth of a second so it is likely we will have sufficient data to show
                lastReport = DateTime.Now;

                wsn = new Wsn();

                bwReadCom.RunWorkerAsync();

            }
            else
            {
                label1.Text = "No COM port found...";
            }

        }

        private void portButton_Click( object sender, EventArgs e)
        {
            // alternatively you can download the FTDI C# wrapper for their driver, which works a lot better than the microsoft serialport is you are using windows
            com = new SerialPort( ((Button)sender).Text, 921600, Parity.None, 8, StopBits.One);

            // set end of line to be \r only
            com.NewLine = "\r";

            com.Open();

            // this way we wait at least one tenth of a second so it is likely we will have sufficient data to show
            lastReport = DateTime.Now;

            wsn = new Wsn();

            bwReadCom.RunWorkerAsync();

            // remove any buttons we created
            foreach (Button btn in ports)
            {
                Controls.Remove(btn);
            }

            ports = new List<Button>();
        }

        // Yeah yeah, I know.. This is a very very bad and highly inefficient example... but it works :-)
        private int Base64(char c) { return "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=".IndexOf(c); }
        private int Hex(   char c) { return "0123456789ABCDEF".IndexOf(c); }
        private int WbId(  char c) { return "ABCD".IndexOf(c); }
        private int WbBtn(char c)  { return "0123456".IndexOf(c); } // note: 7 is a valid code, but it means the button is not pressed
        private int WbTtl( char c) { return "012".IndexOf(c); }     // note: 3 is a correct value, but it means that the rssi is invalid, so...

        private int TwosComplement( int uint8 ) { return (uint8 >= 128) ? (-256 + uint8) : uint8; }

        private void bwReadCom_DoWork(object sender, DoWorkEventArgs e)
        {
            while ( !bwReadCom.CancellationPending )
            {
                // read a string
                string data = com.ReadLine(); // not handling exceptions... 

                // start of line is \n, remove anything before it
                int startPos = data.IndexOf('\n');
                if (startPos != -1) data = data.Substring(startPos + 1);

                // rudimentary parser
                // example data:
                // Dq>702FF3F
                // Bk>7000043
                // Cl>700013E
                // Dq:B0E0/3P3V0V0W0S0R0f0M0
                // Bk:K1F0D1N1b0P0U0S0O0U0j0
                // Cm:F2/3G2e2T0W0U1U0T0/3U0

                // get the time
                DateTime now = DateTime.Now;

                // parse
                if ( ( data.Length == 10 ) && ( data[2] == '>' ) )
                {
                    // probably a correctly formatted short line
                    int id = WbId(data[0]);
                    if (id != -1)
                    {
                        WristBand wb = wsn.wristband[id];
                        wb.lastShort = now;
                        wb.strength = Base64(data[1]);
                        wb.button = WbBtn(data[3]);
                        wb.x = TwosComplement((Hex(data[4]) * 16) + (Hex(data[5])));
                        wb.y = TwosComplement((Hex(data[6]) * 16) + (Hex(data[7])));
                        wb.z = TwosComplement((Hex(data[8]) * 16) + (Hex(data[9])));
                    }
                }
                else
                if ( ( data.Length == 25 ) && ( data[2] == ':') )
                {
                    // probably a correctly formatted long line
                    int id = WbId(data[0]);
                    if (id != -1)
                    {
                        WristBand wb = wsn.wristband[id];
                        wb.lastLong = now;
                        wb.strength = Base64(data[1]);

                        // read wristbands with a lower id 
                        for (int i = 0; i < id; i++)
                        {
                            wb.rssi[i] = Base64(data[3 + (2 * i)]);
                            wb.ttl[i] = WbTtl(data[4 + (2 * i)]);
                        }

                        // clear the id of this wristband: it has no data for itself
                        wb.rssi[id] = -1;
                        wb.ttl[id] = -1;

                        // read wristbands with a higher id and then all the anchors 
                        for (int i = id; i < 11; i++)
                        {
                            wb.rssi[i + 1] = Base64(data[3 + (2 * i)]);
                            wb.ttl[i + 1] = WbTtl(data[4 + (2 * i)]);
                        }
                    }
                }

                // check if we need to update the screen
                if ( ( now - lastReport )  >= TimeSpan.FromMilliseconds( 100 ) )
                {
                    // last report was more than 100 ms ago!
                    lastReport = now;

                    // create a snapshot of the wsn state and throw it to the UI thread for drawing...
                    Wsn wsnCopy = wsn.CreateSnapshot( now );
                    bwReadCom.ReportProgress(1, wsnCopy);
                }
            }

            com.Close();

            if (bwReadCom.CancellationPending) e.Cancel = true;
        }

        private void bwReadCom_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            // we are on the UI thread: we can update the form here...
            Wsn wsn = (Wsn)(e.UserState);

            label1.Text = " ID | RSS | BTN |  X  |  Y  |  Z  |  A  |  B  |  C  |  D  |  1  |  2  |  3  |  4  |  5  |  6  |  7  |  8  |\r\n" +
                          "----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+\r\n" +
                          " A  |" + wsn.wristband[0].ToString() + "\r\n" +
                          "----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+\r\n" +
                          " B  |" + wsn.wristband[1].ToString() + "\r\n" +
                          "----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+\r\n" +
                          " C  |" + wsn.wristband[2].ToString() + "\r\n" +
                          "----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+-----+\r\n" +
                          " D  |" + wsn.wristband[3].ToString() + "\r\n";
        }
    }

    // class to store the collected data and to function as a snapshot.
    public class Wsn
    {
        public WristBand[] wristband = { new WristBand(), new WristBand(), new WristBand(), new WristBand() };

        public Wsn CreateSnapshot( DateTime now )
        {
            Wsn newWsn = new Wsn();

            for (int i = 0; i < 4; i++) wristband[i].SaveSnapshot(now, newWsn.wristband[i]);

            return newWsn;
        }
    }

    public class WristBand
    {
        public int button;
        
        // first the 4 wristbands, then the 8 anchors. wristbands include the wristband itself with ttl 3 and strength 0
        public int[] rssi = new int[ 12 ];
        public int[] ttl = new int[12];

        public int x;
        public int y;
        public int z;
        public int strength;
        public DateTime lastShort;
        public DateTime lastLong;

        public void SaveSnapshot( DateTime now, WristBand copy )
        {
            copy.lastShort = lastShort;
            copy.lastLong = lastLong;

            copy.strength = -1;

            if ( ( now - lastLong ) <= TimeSpan.FromSeconds( 3 ) )
            {
                // the last long message is still valid
                copy.strength = strength;
                copy.rssi = (int[])(rssi.Clone());
                copy.ttl = (int[])(ttl.Clone());
            }
            else
            {
                // the last long message is no longer valid
                copy.ttl = new int[] { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
            }

            if ((now - lastShort) <= TimeSpan.FromSeconds(3))
            {
                // the last short message is still valid
                copy.button = button;
                if ( lastShort > lastLong ) copy.strength = strength;
                copy.x = x;
                copy.y = y;
                copy.z = z;
            }
            else
            {
                // the last short message is no longer valid
                copy.button = -1;
                copy.x = int.MinValue;
                copy.y = int.MinValue;
                copy.z = int.MinValue;

            }
        }

        public override string ToString()
        {
            // " RSS | BTN |  X  |  Y  |  Z  |  A  |  B  |  C  |  D  |  1  |  2  |  3  |  4  |  5  |  6  |  7  |  8  |"

            string txt = " " + ( ( strength != -1 ) ? ( - 1 * ( strength + 30 ) ).ToString() : "   " ) + " |" +
                         "  " + ( ( button != -1 ) ?  button.ToString() : " " ) +                       "  |" +
                         ( ( x != int.MinValue ) ? string.Format( "{0,4}", x.ToString() ) : "    " ) +   " |" +
                         ( ( y != int.MinValue ) ? string.Format( "{0,4}", y.ToString() ) : "    " ) +   " |" +
                         ( ( z != int.MinValue ) ? string.Format( "{0,4}", z.ToString() ) : "    " ) +   " |";

            for ( int i = 0; i < 12; i++ )
            {
                txt += " " + ((ttl[i] != -1) ? (-1 * (rssi[i] + 30)).ToString() : "   ") + " |";
            }
           
            return txt;
        }
    } 
}
